# Vibe Launcher

A lightweight native Android launcher starter with a dark, iOS-inspired look and muted green accents.

## Open and build
1. Install Android Studio.
2. Open this folder as a project.
3. Let Gradle sync.
4. Build > Build APK(s), or run on an Android device.
5. Install the APK, press Home, and choose **Vibe Launcher** as the Home app.

## Notes
- Minimum Android version: Android 6.0 (API 23).
- This is a starter project, not a finished iOS clone.
- The home screen currently shows a minimal layout and a small dock; “All apps” opens an app drawer with search.
- Android manufacturers differ in how they handle home apps and app visibility. Test on your device.
- No internet permission, analytics, ads, or background services are included.
