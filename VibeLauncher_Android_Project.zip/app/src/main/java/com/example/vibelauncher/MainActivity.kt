package com.example.vibelauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.text.TextWatcher
import android.text.Editable

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 7, 6)
    private val green = Color.rgb(170, 213, 123)
    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var grid: GridLayout
    private var allApps: List<ResolveInfo> = emptyList()
    private var drawerOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        allApps = loadApps()
        showHome()
    }

    private fun loadApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }

    private fun showHome() {
        drawerOpen = false
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(14))
            setBackgroundColor(bg)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(label("9:41", 16f, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(36), 1f))
        top.addView(label("●  ▮▮▮  ▰", 12f, Color.WHITE), LinearLayout.LayoutParams(-2, dp(36)))
        root.addView(top)

        val date = label("THURSDAY, OCTOBER 15", 11f, green, true)
        date.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        date.letterSpacing = 0.12f
        val dateParams = LinearLayout.LayoutParams(-1, dp(36))
        dateParams.topMargin = dp(22)
        root.addView(date, dateParams)

        val title = label("Keep it simple.", 30f, Color.WHITE, true)
        title.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        root.addView(title, LinearLayout.LayoutParams(-1, dp(48)))

        val subtitle = label("Dark mode. Smooth moves.", 14f, Color.rgb(145, 151, 146))
        subtitle.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(28)))

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val favoritePackages = listOf(
            "com.android.settings", "com.google.android.dialer",
            "com.google.android.apps.messaging", "com.android.chrome"
        )
        val favorites = favoritePackages.mapNotNull { pkg ->
            allApps.firstOrNull { it.activityInfo.packageName == pkg }
        }.take(4)

        val iconRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(20, 23, 21), dp(28).toFloat())
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        val homeApps = if (favorites.isNotEmpty()) favorites else allApps.take(4)
        homeApps.forEach { app -> iconRow.addView(appTile(app, 60)) }
        val dockParams = LinearLayout.LayoutParams(-1, dp(94))
        dockParams.bottomMargin = dp(16)
        root.addView(iconRow, dockParams)

        val button = TextView(this).apply {
            text = "⌕     Search apps"
            textSize = 15f
            setTextColor(Color.rgb(190, 195, 190))
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(25, 29, 26), dp(22).toFloat())
            setOnClickListener { showDrawer() }
        }
        root.addView(button, LinearLayout.LayoutParams(-1, dp(52)))

        val allButton = TextView(this).apply {
            text = "All apps  ↗"
            textSize = 13f
            setTextColor(green)
            gravity = Gravity.CENTER
            setOnClickListener { showDrawer() }
        }
        root.addView(allButton, LinearLayout.LayoutParams(-1, dp(42)))
        setContentView(root)
    }

    private fun showDrawer() {
        drawerOpen = true
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(10))
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val back = label("‹", 32f, Color.WHITE)
        back.setOnClickListener { showHome() }
        header.addView(back, LinearLayout.LayoutParams(dp(42), dp(48)))
        header.addView(label("Applications", 22f, Color.WHITE, true),
            LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(header)

        search = EditText(this).apply {
            hint = "Search apps"
            textSize = 15f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(125, 132, 126))
            background = rounded(Color.rgb(25, 29, 26), dp(18).toFloat())
            setPadding(dp(16), 0, dp(16), 0)
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(50))
        searchParams.topMargin = dp(10)
        searchParams.bottomMargin = dp(14)
        root.addView(search, searchParams)

        val scroll = ScrollView(this)
        grid = GridLayout(this).apply {
            columnCount = 4
            useDefaultMargins = false
        }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        renderApps("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        setContentView(root)
    }

    private fun renderApps(query: String) {
        grid.removeAllViews()
        val filtered = allApps.filter {
            it.loadLabel(packageManager).toString().contains(query, ignoreCase = true)
        }
        filtered.forEach { app ->
            val tile = appTile(app, 54)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(104)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            grid.addView(tile, params)
        }
    }

    private fun appTile(app: ResolveInfo, iconSize: Int): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(5), dp(3), dp(5))
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(app.activityInfo.packageName)
                if (launch != null) {
                    try { startActivity(launch) } catch (_: Exception) {}
                }
            }
        }
        val icon = ImageView(this).apply {
            setImageDrawable(app.loadIcon(packageManager))
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rounded(Color.rgb(28, 32, 29), dp(17).toFloat())
            setPadding(dp(7), dp(7), dp(7), dp(7))
        }
        box.addView(icon, LinearLayout.LayoutParams(dp(iconSize), dp(iconSize)))
        val name = label(app.loadLabel(packageManager).toString(), 10.5f, Color.rgb(226, 230, 226))
        name.maxLines = 1
        name.ellipsize = android.text.TextUtils.TruncateAt.END
        val nameParams = LinearLayout.LayoutParams(-1, dp(28))
        nameParams.topMargin = dp(4)
        box.addView(name, nameParams)
        return box
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) showHome() else super.onBackPressed()
    }
}
